# Support

If you have a question, find a bug, or just want to say hi, please open an [issue on GitHub](https://github.com/cferdinandi/kraken/issues).