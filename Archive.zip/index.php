<? include("header.php") ?>

<? include("intro.php") ?>

<? include("clean.php") ?>
<? include("economy.php") ?>
<? include("innovation.php") ?>
<? include("future.php") ?>
<? include("appendix.php") ?>

<? include("callToAction.php") ?>

<? include("footer.php") ?>

