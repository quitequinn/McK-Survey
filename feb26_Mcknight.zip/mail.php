<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>

<script type="text/javascript">
$(document).ready(function() {
    $("#submit_btn").click(function() {

      var proceed = true;
        //simple validation at client's end
        //loop through each field and we simply change border color to red for invalid fields
    $("#contact_form input[required=true], #contact_form textarea[required=true]").each(function(){
      $(this).css('border-color','');
      if(!$.trim($(this).val())){ //if this field is empty
        $(this).css('border-color','red'); //change border color to red
        proceed = false; //set do not proceed flag
      }
      //check invalid email
      var email_reg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      if($(this).attr("type")=="email" && !email_reg.test($.trim($(this).val()))){
        $(this).css('border-color','red'); //change border color to red
        proceed = false; //set do not proceed flag
      }
    });

        if(proceed) //everything looks good! proceed...
        {
           //data to be sent to server
            var m_data = new FormData();
            m_data.append( 'user_name', $('input[name=name]').val());
            m_data.append( 'user_email', $('input[name=email]').val());
            m_data.append( 'subject', $('select[name=subject]').val());
      m_data.append( 'msg', $('textarea[name=message]').val());
      m_data.append( 'file_attach', $('input[name=file_attach]')[0].files[0]);

            //instead of $.post() we are using $.ajax()
            //that's because $.ajax() has more options and flexibly.
        $.ajax({
              url: 'mail/contact_me.php',
              data: m_data,
              processData: false,
              contentType: false,
              type: 'POST',
              dataType:'json',
              success: function(response){
                 //load json data from server and output message
        if(response.type == 'error'){ //load json data from server and output message
          output = '<div class="error">'+response.text+'</div>';
        }else{
            output = '<div class="success">'+response.text+'</div>';
        }
        $("#contact_form #contact_results").hide().html(output).slideDown();
              }
            });


        }
    });

    //reset previously set border colors and hide all message on .keyup()
    $("#contact_form  input[required=true], #contact_form textarea[required=true]").keyup(function() {
        $(this).css('border-color','');
        $("#result").slideUp();
    });
});
</script>

<div class="form-style" id="contact_form">
    <div id="contact_results"></div>
    <div id="contact_body">
        <label>
            <input type="text" name="name" id="name" placeholder="Company Name" required="true" class="input-field"/>
        </label>
        <label class="grid-half">
            <input type="text" name="name" id="year" placeholder="Year founded" required="true" class="input-field"/>
        </label>
        <label class="grid-half">
            <input type="text" name="name" id="industry" placeholder="Industry" required="true" class="input-field"/>
        </label>
        <label>
            <input type="text" name="name" id="owner" placeholder="Owner/Principle Name(s)" required="true" class="input-field"/>
        </label>
        <label>
            <input type="email" name="email" placeholder="Contact Email" required="true" class="input-field"/>
        </label>
        <label for="field5">
            <textarea name="message" id="message" placeholder="Mission Statment (500 Word Max)" class="textarea-field" maxlength="50-" required="true"></textarea>
        </label>
        <label for="field5">
            <textarea name="message" id="message" placeholder="Company product or service" class="textarea-field" required="true"></textarea>
        </label>
        <label class="grid-half">
            <input type="file" name="file_attach" class="input-field" /><span>Upload logo</span>
        </label>
        <label class="grid-half">
            <input type="submit" id="submit_btn" value="Submit" />
        </label>
    </div>
</div>
